---
name: Autonomous Life-Critical Logistics
colors:
  surface: '#12131a'
  surface-dim: '#12131a'
  surface-bright: '#383941'
  surface-container-lowest: '#0d0e15'
  surface-container-low: '#1a1b22'
  surface-container: '#1e1f26'
  surface-container-high: '#292931'
  surface-container-highest: '#33343c'
  on-surface: '#e3e1ec'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#e3e1ec'
  inverse-on-surface: '#2f3038'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#ffb4ac'
  on-secondary: '#690007'
  secondary-container: '#921517'
  on-secondary-container: '#ff9f95'
  tertiary: '#ffb3ad'
  on-tertiary: '#68000a'
  tertiary-container: '#d63135'
  on-tertiary-container: '#fff6f5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ac'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#8e1214'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#12131a'
  on-background: '#e3e1ec'
  surface-variant: '#33343c'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '600'
    lineHeight: 80px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 3rem
  margin-sm: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-stakes precision, biological vitality, and cold algorithmic efficiency. The target audience comprises hospital networks, autonomous fleet operators, organ transport coordinators, and precision medical logistics directors. The UI evokes clinical confidence, urgent responsiveness, and quiet luxury.

The aesthetic fuses Apple-grade industrial precision with the focused utility of advanced computational systems:
- **Pitch-Black Canvases**: True blacks (`#000000`) and deep obsidian voids (`#030712`) eliminate visual noise, letting mission-critical indicators surface with surgical clarity.
- **Biomedical Crimson Accents**: Arterial, deep crimson and glowing red hues act as precise signals of life, urgency, and automated routing, avoiding indiscriminate neon tropes in favor of deliberate focal points.
- **Liquid Glass & Specular Definition**: Frosted translucent layers (`backdrop-blur-xl`), hyper-subtle inner borders, and directional light catchers provide depth without breaking structural discipline.
- **Surgical Restraint**: Spacing is generous, typography is meticulously calibrated, and decorative chrome is ruthlessly excised.

## Colors

The palette operates in strict darkness, allowing saturated crimson wavelengths to signify telemetry, life-support continuity, and automated routing metrics.

### Surface Hierarchy
- **Canvas Base**: `#000000` to `#030712` (Void Black)
- **Glass Base (Translucent Layer 1)**: `rgba(9, 13, 24, 0.65)` with `rgba(255, 255, 255, 0.08)` border
- **Glass Elevated (Translucent Layer 2)**: `rgba(18, 24, 38, 0.75)` with `rgba(255, 255, 255, 0.12)` border
- **Glass Highlight / Active**: `rgba(220, 38, 38, 0.08)` with `rgba(239, 68, 68, 0.3)` border

### Arterial & Signal Accents
- **Deep Arterial Red**: `#7F1D1D` (Subdued states, container borders, telemetry baselines)
- **Crimson Core**: `#991B1B` (Secondary status, sustained alerts)
- **Signal Red (Primary)**: `#DC2626` (Primary action vectors, vital signs, live tracking nodes)
- **Pulse Red**: `#EF4444` (Interactive hovers, critical beacons, dynamic pings)

### Text & Neutral Spectrum
- **Primary Type**: `#FFFFFF` (High-contrast headlines, vital data points)
- **Secondary Type**: `#E4E4E7` (Zinc-200, clear subheaders)
- **Muted Body**: `#A1A1AA` (Zinc-400, neutral prose and analytical logs)
- **Subtle Metadata**: `#71717A` (Zinc-500, column labels, micro-captions)
- **Borders & Dividers**: `rgba(255, 255, 255, 0.08)` hairline rules

## Typography

The type system balances the neutral, systematic clarity of **Inter** for narrative and marketing headlines with the unyielding technical rigor of **JetBrains Mono** for logistical coordinates, payloads, flight metrics, and real-time biometric telemetry.

### Typographic Hierarchy Rules
- **Display & Section Headlines**: Set tightly tracked (`-0.02em` to `-0.04em`) in pure `#FFFFFF` with medium-to-semibold weights. Avoid heavy black weights to maintain a clean, clinical silhouette.
- **Narrative Copy**: Styled in muted Zinc (`#A1A1AA`) to establish effortless visual contrast against the bold white headers.
- **Telemetry & Telematics**: All mission-critical statistics, timestamps, lat/long figures, and battery/temperature counters must render in `JetBrains Mono` to guarantee tabular numeric alignment and an authentic operations-console feel.

## Layout & Spacing

The layout is built on a responsive 12-column grid anchored by a maximum container width of `1280px` for structured dashboard modules, extending to `1440px` for landing page showcases.

### Layout Rhythm
- **Rhythm Multiplier**: Fixed on an 8px base rhythm (`0.5rem = 8px`). Micro-gaps use 4px (`space-xs`).
- **Section Pacing**: Landing sections use spacious vertical padding (`6rem` to `8rem`) on desktop to allow intricate glass components to breathe against the deep obsidian canvas.

### Form Factor Behavior
- **Desktop (>= 1024px)**: 12-column grid, `gutter = 1.5rem` (24px), outer margins `3rem` (48px). Telemetry panels, globe visualizations, and dispatch routes sit side-by-side.
- **Tablet (768px - 1023px)**: 8-column grid, `gutter = 1.25rem` (20px), outer margins `2rem` (32px). Complex data arrays compress into tabbed split-views.
- **Mobile (< 768px)**: 4-column grid, `gutter-sm = 1rem` (16px), outer margins `margin-sm = 1.25rem` (20px). HUD metrics stack linearly with full-width swipeable cards.

## Elevation & Depth

Visual hierarchy does not use murky drop shadows. Instead, it relies on light transmission, edge illumination, and luminous chromatic diffusion:

### 1. Liquid Glassmorphism & Frosted Plates
- **Subsurface Blur**: `backdrop-blur-xl` (24px to 32px) coupled with semi-translucent fills (`rgba(6, 10, 20, 0.65)`).
- **Surface Layering**: Higher z-index panels reduce blur slightly to 16px and increase surface opacity to `rgba(18, 24, 38, 0.85)` to simulate optical density.

### 2. Specular Highlights & Hairline Outlines
- **Ghost Borders**: Every floating card or control receives a `1px` border of `rgba(255, 255, 255, 0.08)`.
- **Specular Top Edge**: Cards feature an asymmetric subtle inner box-shadow: `inset 0 1px 0 0 rgba(255, 255, 255, 0.18)` simulating a overhead luminescent sterile lab light.

### 3. Arterial Glow & Under-Lighting
- **Crimson Ambience**: Primary cards and active drone transport nodes project a soft ambient back-glow: `0 0 40px -10px rgba(220, 38, 38, 0.25)`.
- **Radial Field**: Background section accents use diffused, off-center radial gradients (`radial-gradient(circle at 50% 0%, rgba(127, 29, 29, 0.15) 0%, transparent 70%)`) to create cinematic spatial presence without muddying typography.

## Shapes

The design uses a refined curvature profile (`roundedness: 2`):
- **Base Element Radius**: Inputs, buttons, and telemetry chips adopt `8px` (`0.5rem`).
- **Surface & Panel Radius**: Logistics cards, glass modal windows, and map HUDs adopt `16px` (`rounded-lg: 1rem`).
- **Large Glass Pods**: Hero visual displays and data visualizers scale to `24px` (`rounded-xl: 1.5rem`).
- **Telemetry Pills**: Live status beacons and pill badges are fully rounded (`9999px`) to visually counter-balance the rectilinear grid.

## Components

### Buttons & Interactive Controls
- **Primary CTA**: Crimson Core gradient (`linear-gradient(180deg, #EF4444 0%, #DC2626 100%)`), solid white text, `8px` radius. Features a hairline top specular border `inset 0 1px 0 rgba(255,255,255,0.3)` and an arterial drop glow `0 0 20px rgba(220, 38, 38, 0.35)`.
- **Secondary (Glass) Action**: Background `rgba(255, 255, 255, 0.03)`, border `1px solid rgba(255, 255, 255, 0.12)`, text `#FFFFFF`. Hover transitions surface opacity to `rgba(255, 255, 255, 0.08)` with border color shifting to `rgba(239, 68, 68, 0.4)`.

### Telemetry Badges & Chips
- Fully rounded pills (`height: 24px` to `28px`), font: `JetBrains Mono` (`label-mono-sm`).
- **Live Status Chip**: Background `rgba(220, 38, 38, 0.1)`, border `1px solid rgba(220, 38, 38, 0.3)`, text `#EF4444`. Includes an active 6px pulsating dot with a CSS radial ripple animation.

### Cards & Fleet Display Modules
- Built on `backdrop-blur-xl`, background `rgba(6, 10, 20, 0.65)`, border `1px solid rgba(255, 255, 255, 0.08)`.
- Card headers maintain separation through an ultra-thin divider: `1px solid rgba(255, 255, 255, 0.05)`.
- Hover behavior: Specular highlight brightens (`border-color: rgba(255, 255, 255, 0.18)`), accompanied by an arterial corner bleed.

### Form Inputs & Telemetry Fields
- Monolithic dark fill (`#030712`), border `1px solid rgba(255, 255, 255, 0.1)`. Placeholder text in `#71717A`.
- Active focus state: Hairline border shifts to `#DC2626` accompanied by an outer shadow ring `0 0 0 3px rgba(220, 38, 38, 0.15)`. Labels sit above inputs in `JetBrains Mono` uppercase with high tracking.

### Specialized Logistics Components
- **Payload Thermal Indicator**: A horizontal micro-bar monitoring organ or blood payload temperature, utilizing a glass rail with a crimson-to-emerald gradient fill and monospaced float readouts.
- **Flight Route Vector Line**: SVG polyline featuring dynamic dash arrays (`stroke: #EF4444`, `stroke-width: 2px`) overlaid across darkened satellite tiles, ending in a high-pulse destination beacon.